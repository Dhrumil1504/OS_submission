#pragma once

void blinkled(void);