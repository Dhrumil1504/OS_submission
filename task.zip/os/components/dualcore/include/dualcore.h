#pragma once

void dualcore(void);