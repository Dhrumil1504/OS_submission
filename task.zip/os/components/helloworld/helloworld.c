#include "esp_log.h"


static const char *TAG = "Hello World LOGGER";

void helloworld(void)
{
    
    ESP_LOGI(TAG,"Hello World\n");
}