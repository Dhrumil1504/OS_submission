#pragma once

void lcd_helloworld(void);