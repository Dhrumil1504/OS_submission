#pragma once

void wifi(void);